﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sorting_Algorithm.Models
{
    public class AdminViewModel
    {

    }
}